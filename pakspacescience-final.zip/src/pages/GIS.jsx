import React from 'react';

function GIS() {
  return (
    <div className="container mt-5">
      <h2>GIS & Remote Sensing in Pakistan</h2>
      <p>Pakistan uses GIS for flood mapping, agriculture, and urban planning.</p>
      <ul>
        <li>SUPARCO GIS Lab</li>
        <li>National Disaster Management Authority (NDMA)</li>
        <li>Punjab Land Records Authority (GIS Mapping)</li>
      </ul>
    </div>
  );
}

export default GIS;