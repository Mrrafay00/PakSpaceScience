import React from 'react';

function Careers() {
  return (
    <div className="container mt-5">
      <h2>Space Science & Aerospace Careers</h2>
      <ul>
        <li>BS/MS in Aerospace Engineering</li>
        <li>Remote Sensing & GIS Certification</li>
        <li>Internships with SUPARCO / IST / NASA collaboration</li>
        <li>Learn Python, MATLAB for data simulation</li>
      </ul>
    </div>
  );
}

export default Careers;