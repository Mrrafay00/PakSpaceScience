import React from 'react';

function Home() {
  return (
    <div className="container mt-5">
      <h1>Welcome to PakSpaceScience</h1>
      <p>Explore Pakistan’s contributions to space, GIS, and aerospace sciences.</p>
    </div>
  );
}

export default Home;