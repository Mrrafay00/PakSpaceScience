import React, { useEffect } from 'react';
import 'leaflet/dist/leaflet.css';
import L from 'leaflet';

function SatelliteTracker() {
  useEffect(() => {
    const map = L.map('satelliteMap').setView([30.3753, 69.3451], 5);

    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
      attribution: '&copy; OpenStreetMap contributors'
    }).addTo(map);

    const marker = L.marker([33.6844, 73.0479]).addTo(map);
    marker.bindPopup('<b>SUPARCO HQ</b><br />Islamabad, Pakistan').openPopup();

    return () => map.remove();
  }, []);

  return (
    <div className="container mt-5">
      <h2>Satellite Tracker</h2>
      <div id="satelliteMap" style={{ height: '500px', width: '100%' }}></div>
    </div>
  );
}

export default SatelliteTracker;