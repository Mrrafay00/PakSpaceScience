import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Home from './pages/Home';
import Navbar from './components/Navbar';
import Footer from './components/Footer';
import SatelliteTracker from './pages/SatelliteTracker';
import Careers from './pages/Careers';
import GIS from './pages/GIS';

function App() {
  return (
    <Router>
      <Navbar />
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/satellite-tracker" element={<SatelliteTracker />} />
        <Route path="/careers" element={<Careers />} />
        <Route path="/gis" element={<GIS />} />
      </Routes>
      <Footer />
    </Router>
  );
}

export default App;